# ProcessosEstocasticosA2

Trabalho da disciplina de Processos Estocásticos. Neste código implementamos 5 diferentes aplicações de filas, sendo elas:

- Time-Dependent Queue (M/M/3)
- Priority Queue (M/M/2)
- Retrial Queue (M/M/1)
- Scheduling Queue: Work Stealing and Work Sharing

Para mais informações, leia o aquivo "Teoria das filas - slides.pdf"
